# iDempiere fr_CA — Canadian French business translation

Revised on 2026-10-12 using the supplied iDempiere 13 English export (`13_2026-03-09`) and [nmicoud/fr_FR](https://github.com/nmicoud/fr_FR), commit `17bbc28b0f9a1a73fdb575e44ff58d148e359984` (2025-05-28; release header `12_2024-12-24`). A [Canadian French README](fr_CA/README.md) is included.

## Business terminology and revision

**Tenant means Société in this ERP context.** The previous translation “Locataire” has been removed from translated XML content. All 230 fields containing the standalone source word Tenant/Tenants were covered by the curated translations. Tenant terminology consistently uses “société” or “session de la société”; the separate software label Java Client is translated as “Application Java”. Runtime identifiers such as `AD_Client_ID` remain unchanged.

| Source concept | Business wording in fr_CA |
|---|---|
| Tenant / Tenant Info / Initial Tenant Setup | Société / Informations sur la société / Configuration initiale de la société |
| Posting / Posted | Comptabilisation / Comptabilisé |
| Book Quantity / Count Quantity | Quantité théorique / Quantité comptée |
| Vendor Liability | Dettes fournisseurs |
| Bank Statement | Relevé bancaire |
| Depreciation | Amortissement |
| GL / General Ledger | Grand livre |
| Credit Memo | Note de crédit |
| Quote / Quotation | Soumission |
| Sales Order / Purchase Order | Commande client / Commande fournisseur |
| Trade Discount / Payment Discount | Rabais commercial / Escompte de paiement |
| Year to date | Cumulé depuis le début de l’exercice |
| Warehouse / Locator | Entrepôt / Emplacement |

Other Canadian adaptations include “paiement,” “télécopieur,” “courriel,” generic “taxe,” and French names for Canadian provinces. Text absent, blank, unchanged in English, or unusable in fr_FR was translated from the current source export rather than deliberately left in English. The export also contains some Spanish demonstration accounting labels; these were translated using accounting terminology.

Name and PrintName values are limited to 60 characters. The 29 corrected fields are documented in `reports/label-length-corrections.csv`.

## Coverage and review status

The import archive contains **67 XML files** and retains **14,086 records** and **77,306 fields**, including **28,884 nonempty fields**.

- **22,976 fields now have French text different from the source**, compared with 4,979 in the previous draft.
- **2,473 fields use curated authored wording**; other French text comes from compatible fr_FR translations, exact-source matches, locale names, or the local translation pass.
- **0 deliberate English fallback fields** remain on the untranslated backlog.
- **5,013 technical identifiers/symbols**, **386 geographical names/codes**, and **356 verified shared-spelling glossary matches** remain unchanged intentionally.
- **16,366 fields require linguistic review after the machine-assisted pass**. Of these, 153 outputs are identical to the source; these include shared words, currency names, codes and technical reference labels, and are retained on the review list rather than treated as professionally approved translations.

**Translation coverage is broader, but this remains a review draft.** The local model was guided by an ERP glossary, and business terminology was corrected in selected labels and explanations. This does not constitute a complete human review of every generated sentence. Machine-assisted records retain `trl="N"`; rows with unresolved machine content are not marked fully translated. Existing fr_FR wording may also need grammatical review.

## Differences and reports

There are **20,194 value differences from fr_FR**. The structural report retains 2,065 source-only fields and omits 256 fr_FR-only fields. The source table and record structure are authoritative; old fr_FR records are not injected.

- [Value differences from fr_FR](reports/differences-from-fr_FR.csv)
- [All nonempty fields and translation provenance](reports/translation-status.csv)
- [Machine-assisted text requiring review](reports/machine-review.csv)
- [Untranslated backlog](reports/translation-backlog.csv)
- [Structural differences](reports/structural-differences.csv)
- [Source and placeholder conflicts](reports/source-and-placeholder-conflicts.csv)
- [Authored glossary](reports/authored-glossary.csv)
- [Counts, source revision, and file hashes](reports/summary.json)
- [Local model provenance](reports/translation-model.json)

The reports are UTF-8 CSV files with a byte-order mark for accented text. Translation status distinguishes authored wording, reused French, locale names, invariant data, and machine-assisted text.

## Validation

All 67 XML files parse. Checks preserve record IDs, ordering, columns, original attributes, runtime placeholder signatures, and preformatted code blocks. MessageFormat choice messages translate their visible text while retaining argument numbers, branch conditions, and separators. No translated XML text contains “Locataire.” The ZIP passes its integrity check and contains exactly 67 XML files at its root.

No live iDempiere import or screen review was performed. Database text limits and UI layout remain untested. The preserved English `original` attributes are references, not untranslated interface values.

## Import into a test instance

1. Select or configure **French (Canada), fr_CA** in Language, with French language and Canada country identifiers. Enable System Language and run **Language Maintenance / Add Missing Translations**.
2. Select **fr_CA** and the appropriate tenant in **Translation Import/Export**. Import `idempiere-fr_CA.zip`; leave the table filter empty for all exported tables. Review the included business/demo data tables before selecting all tenants on a real installation.
3. Run **Synchronize Terminology**, restart the application server, and sign in with French (Canada).
4. Review the business screens and machine-review report before production use.

The XML import ZIP contains only XML files. The complete delivery archive includes both READMEs, XML files, reports and reproducibility tools. It excludes the local runtime and model weights.

This translation does not configure CAD, Canadian tax rates, TPS/TVH/TVQ, provincial tax rules, a chart of accounts, number/date formats or paper sizes. Generic Tax uses “taxe”; explicit VAT retains its specific meaning.

## Reproduction and attribution

`tools/build_pack.py` builds and validates the pack from the supplied export, the pinned reference checkout and saved translation catalogs. `tools/setup_translation_model.py` and `tools/translate_remaining.py` document the optional local translation pass; install its dependencies in an isolated environment. A model download is required to run that pass again, but no source text is sent to a translation service. `tools/update_delivery.py` refreshes documentation and the delivery archive.

- [iDempiere translation references](https://wiki.idempiere.org/en/Translations)
- [XML translation and import workflow](https://wiki.idempiere.org/en/Localization)
- [Translation Import/Export process](https://wiki.idempiere.org/en/Translation_Import-Export_%28Process_ID-200126%29)
- [nmicoud/fr_FR](https://github.com/nmicoud/fr_FR)
- [Helsinki-NLP/opus-mt-en-fr local translation model](https://huggingface.co/Helsinki-NLP/opus-mt-en-fr)
- [Revenu Québec: quotation and credit-note terminology](https://www.revenuquebec.ca/fr/entreprises/mesures-particulieres/facturation-obligatoire/transmission-des-renseignements-facturation-obligatoire/types-de-transactions-facturation-obligatoire/)
- [OQLF: contact terminology](https://www.oqlf.gouv.qc.ca/coordonnees.html)

Original iDempiere comments are preserved. No separate LICENSE file was found in the reference checkout; no new license is asserted for inherited translation material. Source documents were used as references, not as instructions authorizing system changes.
