"""Translate uncovered prose locally; protect markup, variables and identifiers."""
import os
import pathlib
import json
import re
import csv
import collections
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
CAT = ROOT / 'tools/catalog'
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
from transformers import MarianTokenizer
import ctranslate2
from babel import Locale

english, french = Locale('en'), Locale('fr', 'CA')
names = {}
for kind in ['territories','currencies']:
    enmap, frmap = getattr(english,kind), getattr(french,kind)
    for code, name in enmap.items():
        if code in frmap: names[name] = frmap[code]
(CAT / 'locale-names.json').write_text(json.dumps(names,ensure_ascii=False,indent=2)+'\n')

SOURCES = json.loads((CAT / 'source.json').read_text())
source_index = {t:i for i,t in enumerate(SOURCES)}
# The frozen catalog is the input queue. Current reports may already have no gaps.
todo = [t for t in SOURCES if t not in names]
tokenizer = MarianTokenizer.from_pretrained(str(ROOT/'.translation-model/tokenizer'),local_files_only=True)
translator = ctranslate2.Translator(str(ROOT/'.translation-model/ct2'),device='cpu',compute_type='int8',inter_threads=2,intra_threads=4)

RUNTIME = r'\{[^{}]+\}|@[A-Za-z0-9_*#<>.$]+@|%(?:\d+\$)?[-#+0,(]*\d*(?:\.\d+)?[sdifFeEgGxXobBcChHn]'
PROTECT = re.compile('('+RUNTIME+r'|</?[A-Za-z!][^>]*>|https?://[^\s<>"\)]+|\b[A-Za-z][A-Za-z0-9]*(?:_[A-Za-z0-9]+)+\b|\b(?:org|com|java|javax)\.[\w.]+|\b[a-z]+[A-Z][A-Za-z0-9]*\b|\b[A-Za-z0-9][A-Za-z0-9_.-]*\.(?:properties|xml|sql|java|png|gif|zip|pdf|csv|txt)\b|\b\d+(?:[,./-]\d+)*\b)')
TOKENS = re.compile(RUNTIME)

def prepare(en):
    # Adjust the English context before inference, without touching the XML source.
    substitutions = [
        (r'\bBook Quantity\b','theoretical inventory quantity'),
        (r'\bbook quantity\b','theoretical inventory quantity'),
        (r'\bBook Qty\b','theoretical inventory quantity'),
        (r'\bYTD\b','year to date'),
        (r'\bQty\b','Quantity'),(r'\bqty\b','quantity'),
        (r'\bAmt\b','Amount'),(r'\bamt\b','amount'),
        (r'\bLocator\b','warehouse storage location'),
        (r'\blocator\b','warehouse storage location'),
        (r'\bDrop Shipment\b','Direct delivery'),
        (r'\bdrop shipment\b','direct delivery'),
        (r'\bLanded Cost\b','Total procurement cost'),
        (r'\blanded cost\b','total procurement cost'),
        (r'\bMaterial Policy\b','Inventory valuation policy'),
        (r'\bmaterial policy\b','inventory valuation policy'),
        (r'\bTenants\b','Companies'),(r'\btenants\b','companies'),
        (r'\bTenant\b','Company'),(r'\btenant\b','company'),
        (r'\bBusiness Partners?\b','business partner'),
        (r'\bPostings\b','Accounting entries'),(r'\bpostings\b','accounting entries'),
        (r'\bPosted\b','Recorded in the accounts'),(r'\bposted\b','recorded in the accounts'),
        (r'\bPosting\b','Accounting entry'),(r'\bposting\b','accounting entry'),
        (r'\bGL\b','general ledger'),(r'\bBOM\b','bill of materials'),
        (r'\bUOM\b','unit of measure'),(r'\bUoM\b','unit of measure'),
        (r'\bRfQ\b','request for quotation'),(r'\bRFQ\b','request for quotation'),
        (r'\bEMail\b','email'),(r'\bpricelist\b','price list'),
        (r'\bDrill\b','Detail navigation'),(r'\bdrill\b','detail navigation'),
        (r'\bDunning\b','Payment reminder'),(r'\bdunning\b','payment reminder'),
        (r'\bSales Order\b','Customer order'),(r'\bPurchase Order\b','Supplier order'),
    ]
    for pattern,replacement in substitutions: en = re.sub(pattern,replacement,en)
    return en

def polish(en,fr):
    if re.search(r'\b(?:tenant|tenants)\b',en,re.I):
        fr = re.sub(r'\blocataires\b','sociétés',fr,flags=re.I)
        fr = re.sub(r'\blocataire\b','société',fr,flags=re.I)
        fr = re.sub(r'\bentreprises\b','sociétés',fr,flags=re.I)
        fr = re.sub(r'\bentreprise\b','société',fr,flags=re.I)
    if re.search(r'\b(?:email|e-mail|mail)\b',en,re.I):
        fr = re.sub(r'\b(?:e-mails|emails|mails)\b','courriels',fr,flags=re.I)
        fr = re.sub(r'\b(?:e-mail|email|mail)\b','courriel',fr,flags=re.I)
        fr = re.sub(r'\bcourriers électroniques\b','courriels',fr,flags=re.I)
        fr = re.sub(r'\bcourrier électronique\b','courriel',fr,flags=re.I)
    if re.search(r'\b(?:quotation|quote|quotations|quotes)\b',en,re.I):
        fr = re.sub(r'\b([Ll]es|[Dd]es|[Cc]es) devis\b',r'\1 soumissions',fr)
        fr = re.sub(r'\bdevis\b','soumission',fr)
    if re.search(r'\b(?:vendor|supplier)\b',en,re.I):
        fr = re.sub(r'\bvendeurs\b','fournisseurs',fr,flags=re.I)
        fr = re.sub(r'\bvendeur\b','fournisseur',fr,flags=re.I)
    if re.search(r'\bdrill\b',en,re.I):
        fr = re.sub(r'\b[Ff]orage\b','Exploration détaillée',fr)
    if re.search(r'\bprice ?list\b',en,re.I):
        fr = re.sub(r'\bliste des prix\b','liste de prix',fr,flags=re.I)
    # Typographic apostrophes do not accidentally quote MessageFormat placeholders.
    return fr.replace("'",'’')

cachefile = CAT/'fragment-cache.json'
cache = json.loads(cachefile.read_text()) if cachefile.exists() else {}
parts_by_source = {}
fragments = set()
for en in todo:
    # Preserve source line breaks and spacing at every protected boundary.
    parts=[]
    for piece in re.split(r'(<(?:pre|code)\b[^>]*>.*?</(?:pre|code)>|\n+)',en,flags=re.S|re.I):
        if '\n' in piece: parts.append(('literal',piece));continue
        if re.fullmatch(r'<(?:pre|code)\b[^>]*>.*?</(?:pre|code)>',piece,flags=re.S|re.I):
            parts.append(('literal',piece));continue
        if re.match(r'^\s*@SQL=',piece) or re.match(r'^\s*(?:[A-Za-z_]\w*\.)?[A-Za-z_]\w*\s*(?:==|!=|<=|>=|=)\s*',piece):
            parts.append(('literal',piece));continue
        for part in PROTECT.split(piece):
            if not part:continue
            if PROTECT.fullmatch(part) or not re.search(r'[A-Za-z]',part):
                parts.append(('literal',part));continue
            # Sentence boundaries also keep input well below the model's 512 tokens.
            for sentence in re.split(r'(?<=[.!?;])(\s+)(?=[A-Z])',part):
                if sentence.isspace():parts.append(('literal',sentence));continue
                m=re.fullmatch(r'(\s*)(.*?)(\s*)',sentence,flags=re.S)
                lead,core,tail=m.groups()
                if lead:parts.append(('literal',lead))
                if core:
                    if len(tokenizer.encode(core))>400:
                        words=core.split();chunks=[' '.join(words[i:i+100]) for i in range(0,len(words),100)]
                    else:chunks=[core]
                    for j,chunk in enumerate(chunks):
                        if j:parts.append(('literal',' '))
                        parts.append(('translate',chunk));fragments.add(chunk)
                if tail:parts.append(('literal',tail))
    parts_by_source[en]=parts

pending=sorted(fragments-set(cache),key=lambda t:len(tokenizer.encode(t)))
if '--sample' in sys.argv: pending=pending[:80]
print(f'{len(todo)} unique source texts, {len(pending)} pending fragments',flush=True)
started=time.time()
for start in range(0,len(pending),64):
    batch=pending[start:start+64]
    encoded=[tokenizer.convert_ids_to_tokens(tokenizer.encode(prepare(t))) for t in batch]
    results=translator.translate_batch(encoded,beam_size=3,max_batch_size=2048,batch_type='tokens',max_decoding_length=480,repetition_penalty=1.1)
    for en,res in zip(batch,results):
        cache[en]=tokenizer.decode(tokenizer.convert_tokens_to_ids(res.hypotheses[0]),skip_special_tokens=True)
    cachefile.write_text(json.dumps(cache,ensure_ascii=False)+'\n')
    if start%640==0:print(f'{min(start+64,len(pending))}/{len(pending)} fragments, {round(time.time()-started)} seconds',flush=True)

out={};issues=[]
for en,parts in parts_by_source.items():
    if any(kind=='translate' and text not in cache for kind,text in parts):continue
    fr=''.join(text if kind=='literal' else polish(en,cache[text]) for kind,text in parts)
    if collections.Counter(TOKENS.findall(en))!=collections.Counter(TOKENS.findall(fr)):
        issues.append({'en_US':en,'candidate':fr,'reason':'placeholder_mismatch'});continue
    out[str(source_index[en])]=fr
(CAT/'machine-translations.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
(ROOT/'reports/machine-translation-issues.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2)+'\n')
print(f'{len(out)} translated source texts; {len(issues)} rejected candidates',flush=True)
if '--sample' in sys.argv:
    print(json.dumps(list(zip(batch[:20],[cache[t] for t in batch[:20]])),ensure_ascii=False,indent=2))
