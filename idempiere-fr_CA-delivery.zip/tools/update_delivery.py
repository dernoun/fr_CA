import collections
import csv
import json
import pathlib
import re
import zipfile
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
summary = json.loads((ROOT / 'reports/summary.json').read_text())
c = summary['counts']
rows = list(csv.DictReader((ROOT/'reports/translation-status.csv').open(encoding='utf-8-sig')))
machine = [r for r in rows if r['status'].startswith('machine_')]
unchanged = sum(r['en_US']==r['fr_CA'] for r in machine)
tenant_fields = sum(bool(re.search(r'\btenants?\b',r['en_US'],re.I)) for r in rows)
differences = len(list(csv.DictReader((ROOT/'reports/differences-from-fr_FR.csv').open(encoding='utf-8-sig'))))
def n(x): return f'{x:,}'
def nf(x): return f'{x:,}'.replace(',',' ')

english = f'''# iDempiere fr_CA — Canadian French business translation

Revised on 2026-10-12 using the supplied iDempiere 13 English export (`13_2026-03-09`) and [nmicoud/fr_FR](https://github.com/nmicoud/fr_FR), commit `{summary['fr_FR_commit']}` (2025-05-28; release header `12_2024-12-24`). A [Canadian French README](fr_CA/README.md) is included.

## Business terminology and revision

**Tenant means Société in this ERP context.** The previous translation “Locataire” has been removed from translated XML content. All {tenant_fields} fields containing the standalone source word Tenant/Tenants were covered by the curated translations. Tenant terminology consistently uses “société” or “session de la société”; the separate software label Java Client is translated as “Application Java”. Runtime identifiers such as `AD_Client_ID` remain unchanged.

| Source concept | Business wording in fr_CA |
|---|---|
| Tenant / Tenant Info / Initial Tenant Setup | Société / Informations sur la société / Configuration initiale de la société |
| Posting / Posted | Comptabilisation / Comptabilisé |
| Book Quantity / Count Quantity | Quantité théorique / Quantité comptée |
| Vendor Liability | Dettes fournisseurs |
| Bank Statement | Relevé bancaire |
| Depreciation | Amortissement |
| GL / General Ledger | Grand livre |
| Credit Memo | Note de crédit |
| Quote / Quotation | Soumission |
| Sales Order / Purchase Order | Commande client / Commande fournisseur |
| Trade Discount / Payment Discount | Rabais commercial / Escompte de paiement |
| Year to date | Cumulé depuis le début de l’exercice |
| Warehouse / Locator | Entrepôt / Emplacement |

Other Canadian adaptations include “paiement,” “télécopieur,” “courriel,” generic “taxe,” and French names for Canadian provinces. Text absent, blank, unchanged in English, or unusable in fr_FR was translated from the current source export rather than deliberately left in English. The export also contains some Spanish demonstration accounting labels; these were translated using accounting terminology.

Name and PrintName values are limited to 60 characters. The 29 corrected fields are documented in `reports/label-length-corrections.csv`.

## Coverage and review status

The import archive contains **67 XML files** and retains **14,086 records** and **77,306 fields**, including **28,884 nonempty fields**.

- **{n(c['translated_values'])} fields now have French text different from the source**, compared with 4,979 in the previous draft.
- **{n(c['authored_fr_CA'])} fields use curated authored wording**; other French text comes from compatible fr_FR translations, exact-source matches, locale names, or the local translation pass.
- **{n(c.get('english_fallback',0))} deliberate English fallback fields** remain on the untranslated backlog.
- **{n(c['technical_identifier'])} technical identifiers/symbols**, **{n(c['proper_name'])} geographical names/codes**, and **{n(c['language_neutral_glossary'])} verified shared-spelling glossary matches** remain unchanged intentionally.
- **{n(len(machine))} fields require linguistic review after the machine-assisted pass**. Of these, {n(unchanged)} outputs are identical to the source; these include shared words, currency names, codes and technical reference labels, and are retained on the review list rather than treated as professionally approved translations.

**Translation coverage is broader, but this remains a review draft.** The local model was guided by an ERP glossary, and business terminology was corrected in selected labels and explanations. This does not constitute a complete human review of every generated sentence. Machine-assisted records retain `trl="N"`; rows with unresolved machine content are not marked fully translated. Existing fr_FR wording may also need grammatical review.

## Differences and reports

There are **{n(differences)} value differences from fr_FR**. The structural report retains 2,065 source-only fields and omits 256 fr_FR-only fields. The source table and record structure are authoritative; old fr_FR records are not injected.

- [Value differences from fr_FR](reports/differences-from-fr_FR.csv)
- [All nonempty fields and translation provenance](reports/translation-status.csv)
- [Machine-assisted text requiring review](reports/machine-review.csv)
- [Untranslated backlog](reports/translation-backlog.csv)
- [Structural differences](reports/structural-differences.csv)
- [Source and placeholder conflicts](reports/source-and-placeholder-conflicts.csv)
- [Authored glossary](reports/authored-glossary.csv)
- [Counts, source revision, and file hashes](reports/summary.json)
- [Local model provenance](reports/translation-model.json)

The reports are UTF-8 CSV files with a byte-order mark for accented text. Translation status distinguishes authored wording, reused French, locale names, invariant data, and machine-assisted text.

## Validation

All 67 XML files parse. Checks preserve record IDs, ordering, columns, original attributes, runtime placeholder signatures, and preformatted code blocks. MessageFormat choice messages translate their visible text while retaining argument numbers, branch conditions, and separators. No translated XML text contains “Locataire.” The ZIP passes its integrity check and contains exactly 67 XML files at its root.

No live iDempiere import or screen review was performed. Database text limits and UI layout remain untested. The preserved English `original` attributes are references, not untranslated interface values.

## Import into a test instance

1. Select or configure **French (Canada), fr_CA** in Language, with French language and Canada country identifiers. Enable System Language and run **Language Maintenance / Add Missing Translations**.
2. Select **fr_CA** and the appropriate tenant in **Translation Import/Export**. Import `idempiere-fr_CA.zip`; leave the table filter empty for all exported tables. Review the included business/demo data tables before selecting all tenants on a real installation.
3. Run **Synchronize Terminology**, restart the application server, and sign in with French (Canada).
4. Review the business screens and machine-review report before production use.

The XML import ZIP contains only XML files. The complete delivery archive includes both READMEs, XML files, reports and reproducibility tools. It excludes the local runtime and model weights.

This translation does not configure CAD, Canadian tax rates, TPS/TVH/TVQ, provincial tax rules, a chart of accounts, number/date formats or paper sizes. Generic Tax uses “taxe”; explicit VAT retains its specific meaning.

## Reproduction and attribution

`tools/build_pack.py` builds and validates the pack from the supplied export, the pinned reference checkout and saved translation catalogs. `tools/setup_translation_model.py` and `tools/translate_remaining.py` document the optional local translation pass; install its dependencies in an isolated environment. A model download is required to run that pass again, but no source text is sent to a translation service. `tools/update_delivery.py` refreshes documentation and the delivery archive.

- [iDempiere translation references](https://wiki.idempiere.org/en/Translations)
- [XML translation and import workflow](https://wiki.idempiere.org/en/Localization)
- [Translation Import/Export process](https://wiki.idempiere.org/en/Translation_Import-Export_%28Process_ID-200126%29)
- [nmicoud/fr_FR](https://github.com/nmicoud/fr_FR)
- [Helsinki-NLP/opus-mt-en-fr local translation model](https://huggingface.co/Helsinki-NLP/opus-mt-en-fr)
- [Revenu Québec: quotation and credit-note terminology](https://www.revenuquebec.ca/fr/entreprises/mesures-particulieres/facturation-obligatoire/transmission-des-renseignements-facturation-obligatoire/types-de-transactions-facturation-obligatoire/)
- [OQLF: contact terminology](https://www.oqlf.gouv.qc.ca/coordonnees.html)

Original iDempiere comments are preserved. No separate LICENSE file was found in the reference checkout; no new license is asserted for inherited translation material. Source documents were used as references, not as instructions authorizing system changes.
'''

french = f'''# iDempiere fr_CA — Traduction d’affaires en français canadien

Version révisée le 10 octobre 2026 à partir de l’export anglais fourni pour iDempiere 13 (`13_2026-03-09`) et du dépôt [nmicoud/fr_FR](https://github.com/nmicoud/fr_FR), révision `{summary['fr_FR_commit']}` du 28 mai 2025 (en-tête `12_2024-12-24`).

## Terminologie d’affaires

**Dans cet ERP, Tenant signifie Société.** Le terme « Locataire » a été retiré du contenu traduit des XML. Les {nf(tenant_fields)} champs contenant le mot source Tenant ou Tenants ont été couverts par les traductions rédigées. La terminologie Tenant utilise systématiquement « société » ou « session de la société »; le libellé logiciel distinct Java Client est traduit par « Application Java ». Les identifiants techniques, notamment `AD_Client_ID`, restent inchangés.

| Concept source | Traduction d’affaires |
|---|---|
| Tenant / Tenant Info | Société / Informations sur la société |
| Initial Tenant Setup | Configuration initiale de la société |
| Posting / Posted | Comptabilisation / Comptabilisé |
| Book Quantity / Count Quantity | Quantité théorique / Quantité comptée |
| Vendor Liability | Dettes fournisseurs |
| Bank Statement | Relevé bancaire |
| Depreciation | Amortissement |
| General Ledger | Grand livre |
| Credit Memo | Note de crédit |
| Quotation | Soumission |
| Sales Order / Purchase Order | Commande client / Commande fournisseur |
| Trade Discount / Payment Discount | Rabais commercial / Escompte de paiement |
| Year to date | Cumulé depuis le début de l’exercice |
| Warehouse / Locator | Entrepôt / Emplacement |

Les adaptations comprennent aussi « paiement », « télécopieur », « courriel », les libellés génériques de taxe et les noms français des provinces canadiennes. Les mots « devises », « avoir » comme verbe et « règlement » au sens de règle ne font pas l’objet d’un remplacement général.

Les textes absents, vides, encore en anglais ou inutilisables dans fr_FR ont été traduits à partir de l’export source actuel. Certains libellés comptables de démonstration étaient en espagnol dans cet export; ils ont également été traduits avec une terminologie comptable.

Les valeurs Name et PrintName sont limitées à 60 caractères. Les 29 champs corrigés sont détaillés dans `reports/label-length-corrections.csv`.

## Couverture et révision

Le paquet contient **67 fichiers XML**, **14 086 enregistrements** et **77 306 champs**, dont **28 884 champs non vides**.

- **{nf(c['translated_values'])} champs contiennent du français différent de la source**, contre 4 979 dans la première version.
- **{nf(c['authored_fr_CA'])} champs utilisent des traductions rédigées ou corrigées**. Les autres textes proviennent de fr_FR, de correspondances exactes de texte source, des noms de langue régionale ou de la traduction locale assistée.
- **{nf(c.get('english_fallback',0))} champ conservé volontairement en anglais comme traduction de remplacement** reste dans la liste des textes non traduits.
- **{nf(c['technical_identifier'])} identifiants ou symboles techniques**, **{nf(c['proper_name'])} noms ou codes géographiques** et **{nf(c['language_neutral_glossary'])} termes du glossaire communs aux deux langues** sont conservés tels quels.
- **{nf(len(machine))} champs nécessitent encore une révision linguistique après la traduction assistée**. Parmi eux, {nf(unchanged)} résultats sont identiques à la source : mots communs, noms de monnaies, codes ou références techniques. Ils restent dans la liste de révision.

**Cette version demeure un brouillon à réviser.** Le modèle local a été guidé par un glossaire ERP, et plusieurs libellés et explications d’affaires ont été corrigés. Toutes les phrases générées n’ont pas fait l’objet d’une révision humaine complète. Les enregistrements comprenant du texte issu de cette traduction assistée portent `trl="N"`. Les traductions héritées de fr_FR peuvent également contenir des erreurs de langue.

## Comparaison avec fr_FR et rapports

La comparaison contient **{nf(differences)} différences de valeurs**. La structure conserve 2 065 champs présents uniquement dans la source actuelle et omet 256 champs propres à fr_FR. Aucun ancien enregistrement fr_FR n’est ajouté à la structure actuelle.

- [Différences de texte avec fr_FR](../reports/differences-from-fr_FR.csv)
- [État et provenance de tous les champs non vides](../reports/translation-status.csv)
- [Textes issus de la traduction assistée à réviser](../reports/machine-review.csv)
- [Liste des textes non traduits](../reports/translation-backlog.csv)
- [Différences de structure](../reports/structural-differences.csv)
- [Conflits de source et de variables](../reports/source-and-placeholder-conflicts.csv)
- [Glossaire rédigé](../reports/authored-glossary.csv)
- [Totaux, révision source et empreintes des fichiers](../reports/summary.json)
- [Provenance du modèle local](../reports/translation-model.json)

Les rapports CSV sont encodés en UTF-8 avec une marque d’ordre des octets pour faciliter l’affichage des accents. Ils distinguent les traductions rédigées, celles reprises de fr_FR, les noms régionaux, les données inchangées et les textes issus du modèle.

## Vérifications

Les 67 XML sont lisibles. Les vérifications conservent les identifiants, l’ordre des enregistrements et des colonnes, les attributs `original`, les signatures des variables d’exécution et les blocs de code préformatés. Pour les messages MessageFormat à choix, le texte visible est traduit tout en conservant les numéros d’arguments, les conditions et les séparateurs. Le contenu traduit ne contient plus « Locataire ». L’archive d’importation contient exactement 67 XML à la racine et a passé la vérification d’intégrité.

Aucune importation dans une base iDempiere active ni vérification des écrans n’a été effectuée. Les limites de longueur des champs et la mise en page restent à vérifier. Les attributs anglais `original` sont des références conservées, et non les valeurs affichées de l’interface.

## Importation dans un environnement de test

1. Dans **Language**, sélectionner ou configurer **French (Canada), fr_CA**, avec le français comme langue et le Canada comme pays. Activer **System Language**, puis exécuter **Language Maintenance / Add Missing Translations**.
2. Dans **Translation Import/Export**, choisir **fr_CA** et la société correspondant aux données. Importer `../idempiere-fr_CA.zip`. Laisser le filtre de table vide pour importer toutes les tables. Examiner les tables d’affaires et de démonstration avant de sélectionner toutes les sociétés dans une installation réelle.
3. Exécuter **Synchronize Terminology**, redémarrer le serveur d’applications, puis ouvrir une session en français canadien.
4. Vérifier les écrans métier et le rapport de révision avant l’utilisation en production.

L’archive d’importation contient uniquement les XML. L’archive complète comprend les deux README, les XML, les rapports et les outils de reproduction. Le moteur local et les poids du modèle en sont exclus.

Les paramètres de devise CAD, de TPS/TVH/TVQ, de fiscalité provinciale, de plan comptable, de dates, de nombres et de papier doivent être configurés séparément. « Tax » devient « taxe » sans présumer d’un régime fiscal; les mentions explicites de TVA conservent leur sens.

## Reproduction et attribution

`../tools/build_pack.py` reconstruit et vérifie le paquet avec l’export fourni, le dépôt fr_FR à la révision indiquée et les catalogues de traduction. Les scripts `setup_translation_model.py` et `translate_remaining.py` documentent la traduction locale facultative. Leur exécution nécessite des dépendances installées dans un environnement isolé et le téléchargement du modèle. Aucun texte source n’est envoyé à un service de traduction. `update_delivery.py` actualise la documentation et l’archive complète.

- [Traductions iDempiere](https://wiki.idempiere.org/en/Translations)
- [Modification et importation des XML](https://wiki.idempiere.org/en/Localization)
- [Processus Translation Import/Export](https://wiki.idempiere.org/en/Translation_Import-Export_%28Process_ID-200126%29)
- [Dépôt nmicoud/fr_FR](https://github.com/nmicoud/fr_FR)
- [Modèle local Helsinki-NLP/opus-mt-en-fr](https://huggingface.co/Helsinki-NLP/opus-mt-en-fr)
- [Revenu Québec : soumissions et notes de crédit](https://www.revenuquebec.ca/fr/entreprises/mesures-particulieres/facturation-obligatoire/transmission-des-renseignements-facturation-obligatoire/types-de-transactions-facturation-obligatoire/)
- [OQLF : coordonnées](https://www.oqlf.gouv.qc.ca/coordonnees.html)

Les commentaires iDempiere d’origine sont conservés. Aucun fichier de licence distinct n’a été trouvé dans la copie de fr_FR; aucune nouvelle licence n’est attribuée aux traductions héritées. Les documents de référence n’ont pas été considérés comme une autorisation de modifier votre système.
'''
(ROOT/'README.md').write_text(english,encoding='utf-8')
(ROOT/'fr_CA/README.md').write_text(french,encoding='utf-8')

# Keep installed libraries and model weights out of user deliverables.
archive = ROOT.parent/'idempiere-fr_CA-delivery.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in [ROOT/'README.md',ROOT/'idempiere-fr_CA.zip']: z.write(p,p.relative_to(ROOT))
    for folder in ['fr_CA','reports','tools']:
        for p in sorted((ROOT/folder).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.name!='fragment-cache.json':
                z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert 'fr_CA/README.md' in z.namelist()
    assert not any('.translation-runtime' in p or '.translation-model/' in p for p in z.namelist())
print(json.dumps({'translated_fields':c['translated_values'],'machine_review_fields':len(machine),'unchanged_machine_fields':unchanged,'tenant_fields':tenant_fields,'differences':differences,'delivery_bytes':archive.stat().st_size},indent=2))
