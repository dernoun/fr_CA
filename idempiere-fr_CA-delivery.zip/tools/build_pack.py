"""Build an auditable fr_CA draft from the supplied en_US export and pinned fr_FR."""
import collections
import csv
import difflib
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
BASE = pathlib.Path('/Users/mohameddernoun/Downloads/en_US_trlExport_15219061938761396083')
REF = ROOT.parent / 'reference-fr_FR'
OUT = ROOT / 'fr_CA'
OUT.mkdir(exist_ok=True)
REPORTS = ROOT / 'reports'
LABELS = {'Name', 'PrintName', 'PO_Name', 'PO_PrintName', 'MsgText'}
SHORT_LABELS = json.loads((ROOT / 'tools/short-labels.json').read_text())
TOKEN = re.compile(r'\{[^{}]+\}|@[A-Za-z0-9_*#<>.$]+@|%(?:\d+\$)?[-#+0,(]*\d*(?:\.\d+)?[sdifFeEgGxXobBcChHn]')

# Exact English text only; never replace text in original attributes or identifiers.
MANUAL = {
    'Price list cannot be changed because the order contains product lines':
        'La liste de prix ne peut pas être modifiée, car la commande contient des lignes de produits',
    'You can convert a Proposal or Quotation to any other Order document type. You would use this process, if you want to maintain/keep the Proposal or Quotation. The document status needs to be In Process.':
        'Vous pouvez convertir une proposition ou une soumission en un autre type de commande. Utilisez ce processus pour conserver la proposition ou la soumission. Le statut du document doit être « En cours ».',
    'Reopen Order': 'Rouvrir la commande',
    'Open previously closed Order': 'Rouvrir une commande précédemment fermée',
    'Order Header': 'En-tête de la commande', 'Order Line': 'Ligne de commande',
    'Enter and change sales orders': 'Saisir et modifier les commandes clients',
    'Payment date': 'Date de paiement', 'Payment Amount': 'Montant du paiement',
    'Payment Info': 'Informations sur les paiements',
    'Payment selection (manual)': 'Sélection des paiements (manuelle)',
    'Prepare Payment': 'Préparer le paiement', 'Payment Details': 'Détails du paiement',
    'Payment Schedule': 'Calendrier des paiements', 'Import Payment': 'Importer les paiements',
    'Project': 'Projet', 'Combination': 'Combinaison', 'Symbol': 'Symbole',
    'Increment': 'Incrément', 'Suffix': 'Suffixe', 'Text': 'Texte',
    'Total Credit': 'Total au crédit', 'Total Debit': 'Total au débit',
    'Alert': 'Alerte', 'Context': 'Contexte', 'Continue': 'Continuer',
    'Copied': 'Copié', 'Difference': 'Différence', 'Selection': 'Sélection',
    'Resource': 'Ressource', 'Probability': 'Probabilité', 'Seconds': 'Secondes',
    'Address 3': 'Adresse, ligne 3', 'Address 4': 'Adresse, ligne 4',
    'Address 5': 'Adresse, ligne 5', 'Conference': 'Conférence',
    'September': 'Septembre', 'Remuneration': 'Rémunération',
    'Argentina': 'Argentine', 'Australia': 'Australie', 'Bhutan': 'Bhoutan',
    'Chad': 'Tchad', 'Fiji': 'Fidji', 'Finland': 'Finlande', 'Guernsey': 'Guernesey',
    'Singapore': 'Singapour', 'Sudan': 'Soudan', 'Tajikistan': 'Tadjikistan',
    'Uganda': 'Ouganda', 'Suriname': 'Suriname', 'Sierra Leone': 'Sierra Leone',
    'Saint Martin': 'Saint-Martin', 'Saint Barthélemy': 'Saint-Barthélemy',
    'Hong Kong': 'Hong Kong', 'Svalbard and Jan Mayen': 'Svalbard et Jan Mayen',
    'The Grand Total displays the total amount including Tax and Freight in document currency':
        'Le total général comprend les taxes et les frais de transport, dans la devise du document',
    'Total line amount incl. Tax': 'Montant total de la ligne, taxes comprises',
    'Business Partner payment address': 'Adresse de paiement du partenaire commercial',
    'The Payment Date indicates the date the payment was made.':
        'La date de paiement indique la date à laquelle le paiement a été effectué.',
    'Print Format for Orders, Quotes, Offers': 'Format d’impression des commandes, soumissions et offres',
    'Email text used for sending order acknowledgements or quotations':
        'Texte du courriel utilisé pour envoyer les confirmations de commande ou les soumissions',
    'For letters, e.g. "Dear {0}" or "Dear Mr. {0}" - At runtime, "{0}" is replaced by the name':
        'Pour les lettres, par exemple « Bonjour {0} » ou « Bonjour M. {0} » : lors de l’exécution, « {0} » est remplacé par le nom',
    'Tax': 'Taxe', 'Tax ID': 'Numéro d’identification fiscale',
    'Tax Amount': 'Montant de taxe', 'Tax Credit': 'Taxe récupérable',
    'Tax Due': 'Taxe à payer', 'Tax Liability': 'Taxe à remettre',
    'Tax Receivables': 'Taxes à recevoir', 'Price includes Tax': 'Prix taxes comprises',
    'Grand Total': 'Total général', 'Line Amount': 'Montant de la ligne',
    'Line Amt': 'Montant de la ligne', 'Total Lines': 'Total des lignes',
    'Expense Amount': 'Montant des dépenses', 'Tax Rate': 'Taux de taxe',
    'Tax Category': 'Catégorie de taxe', 'Tax Provider': 'Fournisseur de services fiscaux',
    'AP Credit Memo': 'Note de crédit fournisseur', 'AR Credit Memo': 'Note de crédit client',
    'Credit Memo': 'Note de crédit', 'Create Credit Memo': 'Créer une note de crédit',
    'Creates a credit memo based on the invoice.': 'Crée une note de crédit à partir de la facture.',
    'Payment': 'Paiement', 'Payments': 'Paiements', 'Payment Rule': 'Mode de paiement',
    'Payment Term': 'Condition de paiement', 'Payment Terms': 'Conditions de paiement',
    'Payment Selection': 'Sélection des paiements', 'Payment Allocation': 'Affectation des paiements',
    'Payment allocation': 'Affectation du paiement', 'Payment identifier': 'Identifiant du paiement',
    'Payment Selection (manual)': 'Sélection des paiements (manuelle)',
    'Payment Print/Export': 'Impression et exportation des paiements',
    'Check No': 'Numéro de chèque', 'Cheque No': 'Numéro de chèque', 'Check Number': 'Numéro de chèque',
    'Cheque': 'Chèque', 'Cheque Amount': 'Montant du chèque',
    'Discount': 'Rabais', 'Discount %': 'Rabais (%)',
    'Trade Discount': 'Rabais commercial', 'Payment Discount': 'Escompte de paiement',
    'Cash Discount': 'Escompte de caisse', 'Discount Amount': 'Montant du rabais',
    'Discount Days': 'Délai d’escompte', 'Only Discount': 'Avec escompte seulement',
    'Quote': 'Soumission', 'Quotation': 'Soumission', 'Sales Quotation': 'Soumission de vente',
    'Proposal': 'Proposition', 'Order': 'Commande', 'Sales Order': 'Commande client',
    'Purchase Order': 'Commande fournisseur', 'Price List': 'Liste de prix',
    'Product is not on Price List': 'Le produit ne figure pas dans la liste de prix',
    'Fax': 'Télécopieur', 'Facsimile number': 'Numéro de télécopieur',
    'Phone': 'Téléphone', 'Phone 2': 'Autre téléphone', 'Mobile Phone': 'Téléphone cellulaire',
    'ZIP': 'Code postal', 'Postal Code': 'Code postal', 'City': 'Ville',
    'Address': 'Adresse', 'Address 1': 'Adresse, ligne 1', 'Address 2': 'Adresse, ligne 2',
    'EMail': 'Courriel', 'EMail Address': 'Adresse courriel', 'Email': 'Courriel',
    'Send EMail': 'Envoyer un courriel', 'Send Mail': 'Envoyer un courriel',
    'EMail User': 'Utilisateur du courriel', 'EMail Password': 'Mot de passe du courriel',
    'EMail Header': 'En-tête du courriel', 'EMail Footer': 'Pied de page du courriel',
    'EMail Test': 'Test du courriel', 'EMail Recipient': 'Destinataire du courriel',
    'Support EMail': 'Courriel du soutien', 'Mail Server': 'Serveur de courriel',
    'New EMail': 'Nouveau courriel', 'New EMail Address': 'Nouvelle adresse courriel',
    'Mail Template': 'Modèle de courriel', 'Mail Text': 'Texte du courriel',
    'Save': 'Enregistrer', 'Cancel': 'Annuler', 'Close': 'Fermer', 'Delete': 'Supprimer',
    'New': 'Nouveau', 'Edit': 'Modifier', 'Search': 'Rechercher', 'Refresh': 'Actualiser',
    'Print': 'Imprimer', 'Preview': 'Aperçu', 'Export': 'Exporter', 'Import': 'Importer',
    'Copy': 'Copier', 'Paste': 'Coller', 'Cut': 'Couper', 'Select All': 'Tout sélectionner',
    'Next': 'Suivant', 'Previous': 'Précédent', 'Yes': 'Oui', 'No': 'Non',
    'User': 'Utilisateur', 'User Name': 'Nom d’utilisateur', 'Password': 'Mot de passe',
    'Login': 'Connexion', 'Logout': 'Déconnexion', 'Role': 'Rôle', 'Language': 'Langue',
    'Active': 'Actif', 'Description': 'Description', 'Comment': 'Commentaire',
    'Organization': 'Organisation', 'Tenant': 'Société', 'Tenant ID': 'Identifiant de la société',
    'Employee': 'Employé', 'Department': 'Service', 'Cost Center': 'Centre de coûts',
    'Any Cost Center': 'Tout centre de coûts', 'Any Department': 'Tout service',
    'Any Warehouse': 'Tout entrepôt', 'Any Asset': 'Tout actif', 'Any Charge': 'Tous frais',
    'Any Employee': 'Tout employé', 'Always Posted': 'Toujours comptabilisé',
    'Hide when Zero': 'Masquer si la valeur est nulle', 'Display SQL': 'Afficher le SQL',
    'Display Identifier': 'Afficher l’identifiant', 'File Path': 'Chemin du fichier',
    'MIME Type': 'Type MIME', 'SHA256 Checksum': 'Somme de contrôle SHA-256',
    'Scale Factor': 'Facteur d’échelle', 'Column 2': 'Colonne 2',
    'Text Column 1': 'Colonne de texte 1', 'Text Column 2': 'Colonne de texte 2',
    'Text Column 3': 'Colonne de texte 3', 'Text Column 4': 'Colonne de texte 4',
    'Create Distribution Order': 'Créer une commande de distribution',
    'Scheduled Receipt Qty': 'Quantité de réception prévue',
    'Planned Orders Qty': 'Quantité des commandes planifiées',
    'Projected On Hand Qty': 'Quantité disponible projetée',
    'Warehouse': 'Entrepôt', 'Inventory': 'Inventaire', 'Quantity': 'Quantité',
    'Stock Adjustment': 'Ajustement des stocks', 'Stock Movement': 'Mouvement de stock',
    'Stock Transfer': 'Transfert de stock', 'Stock Inquiry': 'Consultation des stocks',
    'Stock in Hand': 'Stock disponible', 'Safety Stock Qty': 'Quantité du stock de sécurité',
    'Freight': 'Transport', 'Freight Amount': 'Montant du transport',
    'Freight Amt': 'Montant du transport', 'Freight Category': 'Catégorie de transport',
    'Freight Charges': 'Frais de transport', 'Freight Terms': 'Conditions de transport',
    'Freight Cost Rule': 'Règle des frais de transport', 'Product for Freight': 'Produit pour le transport',
    'Manufacturer': 'Fabricant', 'Is Manufacturer': 'Est un fabricant',
    'Height': 'Hauteur', 'Weight': 'Poids', 'UOM for Weight': 'Unité de mesure du poids',
    'Country Of Manufacture': 'Pays de fabrication', 'Manufactured Year': 'Année de fabrication',
    'Manufactured': 'Fabriqué', 'Currency': 'Devise', 'Currency To': 'Devise cible',
    'Invoice': 'Facture', 'Invoice Line': 'Ligne de facture', 'Vendor': 'Fournisseur',
    'Customer': 'Client', 'Business Partner': 'Partenaire commercial',
    'Document Type': 'Type de document', 'Document No': 'Numéro de document',
    'Date': 'Date', 'Start Date': 'Date de début', 'End Date': 'Date de fin',
    'Accounting Date': 'Date comptable', 'Date Invoiced': 'Date de facturation',
    'Total': 'Total', 'Amount': 'Montant', 'Balance': 'Solde',
    'EMail from {0} to {1}': 'Courriel de {0} à {1}',
    'The new password is now valid in: {0}': 'Le nouveau mot de passe est maintenant valide dans : {0}',
    'Click to copy a permanent link to this record': 'Cliquez pour copier un lien permanent vers cet enregistrement',
    'Invoices are generated depending on the "Invoicing Rule" selection in the Order':
        'Les factures sont générées selon la règle de facturation sélectionnée dans la commande',
    'Message sent.': 'Message envoyé.', 'EMail sent': 'Courriel envoyé',
    'Could not send EMail': 'Impossible d’envoyer le courriel',
    'Admin User Email': 'Courriel de l’administrateur', 'Normal User Email': 'Courriel de l’utilisateur',
    'Admin User Email is required': 'Le courriel de l’administrateur est obligatoire',
    'Normal User Email is required': 'Le courriel de l’utilisateur est obligatoire',
}

CATALOG = ROOT / 'tools/catalog'
catalog_sources = json.loads((CATALOG / 'source.json').read_text())
MANUAL.update(json.loads((ROOT / 'tools/domain_glossary.json').read_text()))
for batch in sorted(CATALOG.glob('business-*.json')):
    for key, value in json.loads(batch.read_text()).items():
        MANUAL[catalog_sources[int(key)]] = value
MANUAL.update(json.loads((ROOT / 'tools/business-overrides.json').read_text()))
MANUAL.update({
    'Document Before Post':'Document avant comptabilisation',
    'Document After Post':'Document après comptabilisation',
    'If Automatic Period Control is enabled, the current period is calculated based on the system date and you can always post to all days in the current period.  Future Days enable to post to future periods. E.g. today is Apr 15th and Future Days is set to 30, you can post up to May 15th':
        'Si le contrôle automatique des périodes est activé, la période actuelle est déterminée selon la date du système et toutes ses dates sont autorisées pour la comptabilisation. Le nombre de jours futurs autorise la comptabilisation dans les périodes suivantes. Par exemple, le 15 avril, une limite de 30 jours permet de comptabiliser jusqu’au 15 mai.',
    'If Automatic Period Control is enabled, the current period is calculated based on the system date and you can always post to all days in the current period.  History Days enable to post to previous periods.  E.g. today is May 15th and History Days is set to 30, you can post back to April 15th':
        'Si le contrôle automatique des périodes est activé, la période actuelle est déterminée selon la date du système et toutes ses dates sont autorisées pour la comptabilisation. Le nombre de jours antérieurs autorise la comptabilisation dans les périodes précédentes. Par exemple, le 15 mai, une limite de 30 jours permet de comptabiliser à partir du 15 avril.',
    'If selected, only documents with an open status (drafted, in progress, approved, rejected, invalid) and standard user actions (prepare, complete, approve, reject) are allowed to continue.  Use this to prevent having to define details on how automatic processes (unlock, invalidate, post, re-activate) and when the document is closed for normal user action (completed, waiting, closed, voided, reversed).':
        'Si cette option est sélectionnée, seuls les documents ouverts — brouillon, en cours, approuvé, rejeté ou invalide — et les actions usuelles — préparer, finaliser, approuver ou rejeter — peuvent poursuivre le flux. Elle évite de définir le traitement des actions automatiques, telles que déverrouiller, invalider, comptabiliser ou réactiver, ainsi que des documents fermés aux actions usuelles : finalisé, en attente, fermé, annulé ou contrepassé.',
    'After resubmitting, the accounting engine will try to post the document again. You resubmit documents, if they are locked or when the document had posting errors - after fixing the cause (e.g. opening period).':
        'Après la remise en traitement, le moteur comptable tente de comptabiliser le document de nouveau. Remettez en traitement les documents verrouillés ou en erreur de comptabilisation après avoir corrigé la cause, par exemple en ouvrant la période.',
    'Choose the date of the most recent payment that you plan to allocate, but it must be in an open accounting period or it will not post.':
        'Choisissez la date du paiement le plus récent à affecter. Elle doit appartenir à une période comptable ouverte pour permettre la comptabilisation.'
})
manual_folded = collections.defaultdict(set)
for en,fr in MANUAL.items(): manual_folded[' '.join(en.split()).casefold()].add(fr)
MACHINE = json.loads((CATALOG / 'machine-translations.json').read_text()) if (CATALOG / 'machine-translations.json').exists() else {}
MACHINE_SOURCES = {catalog_sources[int(key)]:value for key,value in MACHINE.items()}
LOCALE = json.loads((CATALOG / 'locale-names.json').read_text()) if (CATALOG / 'locale-names.json').exists() else {}

def tokens(text):
    def signature(token):
        if ',choice,' in token:
            head,branches=token[1:-1].split(',choice,',1)
            return '{'+head+',choice,'+'|'.join(re.match(r'\s*([^#<≤]+[#<≤])',b).group(1) for b in branches.split('|'))+'}'
        return token
    return collections.Counter(signature(t) for t in TOKEN.findall(text))

def technical(text, column=None, table=None):
    if column in {'CurSymbol','TaxIndicator','UOMSymbol'}:
        return True
    if table == 'C_Region' and column in {'Name','Description'}:
        return True  # Proper geographical names and region codes; reviewed overrides take priority.
    return (not re.search(r'[A-Za-zÀ-ÿ]',text) or
            bool(re.fullmatch(r'[A-Za-z][A-Za-z0-9]*(?:_[A-Za-z0-9]+)+', text)) or
            bool(re.fullmatch(r'(?:https?|ftp)://\S+',text)) or
            bool(re.fullmatch(r'(?:[A-Z][a-z0-9]*){2,}(?:ID|UU)?',text)) or
            text in {'SQL', 'HTML', 'XML', 'CSV', 'PDF', 'URL', 'UUID', 'SMTP', 'IMAP', 'OK', 'iDempiere'})

def usable(en, fr):
    if not en or not fr or en == fr or tokens(en) != tokens(fr):
        return False
    if code_blocks(en) != code_blocks(fr):
        return False
    # Reject near-identical English variants, corrections and obsolete technical identifiers.
    if difflib.SequenceMatcher(None, en.lower(), fr.lower()).ratio() > .88:
        return False
    return True

def code_blocks(text):
    return re.findall(r'<(?:pre|code)\b[^>]*>.*?</(?:pre|code)>',text,flags=re.S|re.I)

def adapt(en, text):
    # Never replace devises (currencies), avoir as a verb, or règlement as a regulation.
    if re.search(r'\b(?:quote|quotes|quotation|quotations|order|orders)\b', en, re.I):
        text = re.sub(r'\b([Ll]es|[Dd]es|[Cc]es) devis\b', r'\1 soumissions', text)
        text = re.sub(r'\bDevis\b', 'Soumission', text)
        text = re.sub(r'\bdevis\b', 'soumission', text)
    if re.search(r'\bpayments?\b', en, re.I):
        for a, b in [('Règlements','Paiements'),('règlements','paiements'),('Règlement','Paiement'),('règlement','paiement')]:
            text = re.sub(r'\b'+a+r'\b', b, text)
    if re.search(r'\btax(?:es)?\b', en, re.I) and not re.search(r'\bVAT\b', en):
        text = re.sub(r'\bTVA\b', 'taxe', text)
    text = re.sub(r'\bTTC\b', 'taxes comprises', text)
    text = re.sub(r'\bHT\b', 'hors taxes', text)
    if re.search(r'\b(?:fax|facsimile)\b', en, re.I):
        text = re.sub(r'\bfax\b', 'télécopieur', text)
    if re.search(r'\b(?:email|e-mail|mail)\b', en, re.I):
        text = re.sub(r'\bmail\b', 'courriel', text)
    if re.search(r'\bprice list\b', en, re.I):
        text = re.sub(r'\btarif\b', 'liste de prix', text)
    if text.startswith('taxe'): text = 'T'+text[1:]
    return text

def normal(text):
    return ' '.join(text.split())

documents = []
dictionary = collections.defaultdict(set)
global_dictionary = collections.defaultdict(set)
for p in sorted(BASE.glob('*.xml')):
    root = ET.parse(p).getroot()
    q = REF / p.name.replace('en_US', 'fr_FR')
    frroot = ET.parse(q).getroot() if q.exists() else None
    ix = {(r.get('id'), v.get('column')): v for r in frroot for v in r} if frroot is not None else {}
    documents.append((p, root, ix))
    for r in root:
        for v in r:
            fv = ix.get((r.get('id'), v.get('column')))
            en = v.text or ''
            if fv is not None and fv.get('original', '') == v.get('original', '') and usable(en, fv.text or ''):
                global_dictionary[normal(en)].add(fv.text)
                if v.get('column') in LABELS and not technical(en):
                    dictionary[(root.get('table'), v.get('column'), en)].add(fv.text)

counts = collections.Counter()
changes, backlog, conflicts, manifest, table_stats = [], [], [], [], []
status_rows = []
structural = []
for p, root, ix in documents:
    local = collections.Counter()
    basekeys = {(r.get('id'), v.get('column')) for r in root for v in r}
    for key in sorted(set(ix) - basekeys):
        structural.append([root.get('table'), *key, 'fr_FR_only_omitted_from_fr_CA'])
    for key in sorted(basekeys - set(ix)):
        structural.append([root.get('table'), *key, 'en_US_only_retained_in_fr_CA'])
    root.set('language', 'fr_CA')
    for row in root:
        complete = True
        counts['rows'] += 1
        for v in row:
            en = v.text or ''
            col = v.get('column')
            fv = ix.get((row.get('id'), col))
            fr = fv.text or '' if fv is not None else ''
            value, reason = en, 'english_fallback'
            counts['values'] += 1
            if en:
                counts['nonempty'] += 1
                if col in {'CurSymbol','TaxIndicator','UOMSymbol'}:
                    reason = 'technical_identifier'
                elif col in {'Name','PrintName'} and en in SHORT_LABELS:
                    value, reason = SHORT_LABELS[en], 'authored_fr_CA'
                    if value == en: reason = 'technical_identifier'
                elif en in MANUAL or en.strip() in MANUAL:
                    lookup = en if en in MANUAL else en.strip()
                    value, reason = MANUAL[lookup], 'authored_fr_CA'
                    if value == en: reason = 'language_neutral_glossary'
                elif len(manual_folded.get(normal(en).casefold(),set()))==1:
                    value,reason = next(iter(manual_folded[normal(en).casefold()])), 'authored_fr_CA'
                    if value==en:reason='language_neutral_glossary'
                elif en in LOCALE:
                    value, reason = LOCALE[en], 'locale_name'
                    if value == en: reason = 'language_neutral_glossary'
                elif technical(en,col,root.get('table')):
                    reason = 'proper_name' if root.get('table')=='C_Region' else 'technical_identifier'
                elif fv is not None and fv.get('original', '') == v.get('original', '') and usable(en, fr):
                    value, reason = fr, 'reused_fr_FR'
                else:
                    candidates = dictionary.get((root.get('table'), col, en), set())
                    if len(candidates) == 1 and col in LABELS:
                        value, reason = next(iter(candidates)), 'reused_exact_label'
                    elif len(global_dictionary.get(normal(en), set())) == 1:
                        value, reason = next(iter(global_dictionary[normal(en)])), 'reused_exact_source'
                    elif en in MACHINE_SOURCES:
                        value, reason = MACHINE_SOURCES[en], 'machine_fr_CA_review_required'
                        complete = False
                        counts['machine_review_fields'] += 1
                if reason.startswith('machine_'):
                    complete = False
                if value != en:
                    adapted = adapt(en, value)
                    if adapted != value:
                        value, reason = adapted, reason + '_canadian_terms'
                    assert tokens(en) == tokens(value), (p.name, row.get('id'), col, en, value)
                    counts['translated_values'] += 1
                    local['translated_values'] += 1
                elif reason not in {'technical_identifier', 'proper_name', 'language_neutral_glossary'} and not reason.startswith('machine_'):
                    complete = False
                    local['english_fallback'] += 1
                    gap_reason = 'no_usable_translation'
                    if fv is None: gap_reason = 'missing_in_fr_FR'
                    elif not fr: gap_reason = 'blank_in_fr_FR'
                    elif fr == en: gap_reason = 'same_as_English_in_fr_FR'
                    elif fv.get('original', '') != v.get('original', ''): gap_reason = 'source_changed'
                    elif tokens(en) != tokens(fr): gap_reason = 'placeholder_mismatch'
                    backlog.append([root.get('table'), row.get('id'), col, gap_reason, en, fr])
                counts[reason] += 1
                status_rows.append([root.get('table'),row.get('id'),col,reason,en,fr,value])
                if fv is not None and fr and fr != en and (fv.get('original', '') != v.get('original', '') or tokens(en) != tokens(fr)):
                    conflicts.append([root.get('table'), row.get('id'), col, fv.get('original',''), en, fr, value])
                if value != fr:
                    changes.append([root.get('table'), row.get('id'), col, reason, en, fr, value, fv.get('original','') if fv is not None else ''])
            else:
                counts['empty_values'] += 1
                if fr:
                    changes.append([root.get('table'), row.get('id'), col, 'empty_current_source_preserved', en, fr, value, fv.get('original','')])
            v.text = value or None
        row.set('trl', 'Y' if complete else 'N')
        counts['complete_rows' if complete else 'incomplete_rows'] += 1
    target = OUT / p.name.replace('en_US', 'fr_CA')
    raw = p.read_text(encoding='utf-8')
    header = raw[:raw.index('<idempiereTrl')]
    target.write_text(header + ET.tostring(root, encoding='unicode', short_empty_elements=True) + '\n', encoding='utf-8')
    manifest.append({'input': p.name, 'input_sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'output': target.name, 'output_sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
    table_stats.append({'table':root.get('table'), 'rows':len(root), **local})

def write_csv(name, headers, data):
    with (REPORTS / name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f); w.writerow(headers); w.writerows(data)

write_csv('differences-from-fr_FR.csv', ['table','row_id','column','reason','en_US','fr_FR','fr_CA','fr_FR_original'], changes)
write_csv('translation-backlog.csv', ['table','row_id','column','reason','en_US','fr_FR'], backlog)
write_csv('source-and-placeholder-conflicts.csv', ['table','row_id','column','fr_FR_original','current_en_US','fr_FR','fr_CA'], conflicts)
write_csv('structural-differences.csv', ['table','row_id','column','reason'], structural)
write_csv('authored-glossary.csv', ['en_US','fr_CA'], sorted(MANUAL.items()))
write_csv('translation-status.csv', ['table','row_id','column','status','en_US','fr_FR','fr_CA'], status_rows)
write_csv('machine-review.csv', ['table','row_id','column','status','en_US','fr_FR','fr_CA'], [r for r in status_rows if r[3].startswith('machine_')])
commit = subprocess.check_output(['git','-C',str(REF),'rev-parse','HEAD'], text=True).strip()
summary = {'fr_FR_repository':'https://github.com/nmicoud/fr_FR', 'fr_FR_commit':commit, 'counts':dict(counts), 'files':len(documents), 'tables':table_stats, 'manifest':manifest, 'revision_notes':{'tenant_term':'Société','untranslated_fr_FR_policy':'Translate from current source export with curated business glossary and local machine assistance','machine_translation_review_required':True,'machine_model':json.loads((REPORTS/'translation-model.json').read_text()) if (REPORTS/'translation-model.json').exists() else None}}
(REPORTS / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

# Verify every exported record, column, original attribute and runtime placeholder.
for p, _, _ in documents:
    original = ET.parse(p).getroot()
    output = ET.parse(OUT / p.name.replace('en_US','fr_CA')).getroot()
    assert output.get('language') == 'fr_CA'
    assert original.get('table') == output.get('table')
    assert len(original) == len(output)
    for r1,r2 in zip(original,output):
        assert {k:v for k,v in r1.attrib.items() if k!='trl'} == {k:v for k,v in r2.attrib.items() if k!='trl'}
        assert len(r1) == len(r2)
        for v1,v2 in zip(r1,r2):
            assert v1.attrib == v2.attrib
            if v2.get('column') in {'Name','PrintName'}:
                assert len(v2.text or '') <= 60, (p.name,r2.get('id'),v2.get('column'),v2.text)
            assert tokens(v1.text or '') == tokens(v2.text or '')
            assert code_blocks(v1.text or '') == code_blocks(v2.text or ''), (p.name,r1.get('id'),v1.get('column'))
with zipfile.ZipFile(ROOT / 'idempiere-fr_CA.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.glob('*.xml')): z.write(p,p.name)
with zipfile.ZipFile(ROOT / 'idempiere-fr_CA.zip') as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(documents)
print(json.dumps({'files':len(documents),'counts':dict(counts),'differences':len(changes),'conflicts':len(conflicts)},indent=2))
