import os
import pathlib
import json
ROOT = pathlib.Path(__file__).resolve().parents[1]
os.environ['HF_HOME'] = str(ROOT / '.translation-model/cache')
os.environ['HF_HUB_DISABLE_XET'] = '1'
from huggingface_hub import snapshot_download
from transformers import MarianTokenizer
from ctranslate2.converters import TransformersConverter
path = snapshot_download('Helsinki-NLP/opus-mt-en-fr', allow_patterns=['config.json','generation_config.json','pytorch_model.bin','source.spm','target.spm','tokenizer_config.json','vocab.json','README.md'])
output = ROOT / '.translation-model/ct2'
TransformersConverter(path).convert(str(output), quantization='int8', force=True)
MarianTokenizer.from_pretrained(path).save_pretrained(str(ROOT / '.translation-model/tokenizer'))
(ROOT / 'reports/translation-model.json').write_text(json.dumps({'model':'Helsinki-NLP/opus-mt-en-fr','revision':pathlib.Path(path).name,'license':'Apache-2.0','local_processing':True,'human_review_required':True},indent=2)+'\n')
print('Local translation model ready.')
